
/*
* Basic Java
 1 уровень сложности: Проект 1. Двумерные массивы
1 Создайте двумерный массив и заполните его буквами русского алфавита.
2* (по желанию) Пусть в двумерном массиве N элементов. Заполните двумерный массив целыми числами от 1 до N по спирали. Например,
01 02 03 04
12 13 14 05
11 16 15 06
10 09 08 07

Проект 2. Практика алгоритмов
На выбор: либо реализовать любую из сортировок самостоятельно, либо решить задание ниже.
Задание из собеседования Яндекс: дана строка вида AAABBBCCCDDEG…, состоящая только из заглавных символов латинского алфавита. Напишите метод, который «свернёт» строку к виду A4B3C3D2EG, т.е. количество букв записывается цифрой. Если буква одна, то цифра не ставится.


 */

public class TwoDimensionalArray {
    public static void main(String[] args) {
        // 1. Создайте двумерный массив и заполните его буквами русского алфавита.
        char[][] alphabetArray = new char[5][5];
        char currentChar = 'А';

        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                alphabetArray[i][j] = currentChar++;
            }
        }

        // Выводим двумерный массив с буквами русского алфавита
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                System.out.print(alphabetArray[i][j] + " ");
            }
            System.out.println();
        }

        // 2. Заполните двумерный массив целыми числами от 1 до N по спирали.
        int n = 4;
        int[][] spiralArray = new int[n][n];
        int value = 1;
        int startRow = 0, endRow = n - 1, startCol = 0, endCol = n - 1;

        while (value <= n * n) {
            for (int i = startCol; i <= endCol; i++) {
                spiralArray[startRow][i] = value++;
            }
            startRow++;

            for (int i = startRow; i <= endRow; i++) {
                spiralArray[i][endCol] = value++;
            }
            endCol--;

            for (int i = endCol; i >= startCol; i--) {
                spiralArray[endRow][i] = value++;
            }
            endRow--;

            for (int i = endRow; i >= startRow; i--) {
                spiralArray[i][startCol] = value++;
            }
            startCol++;
        }

        // Выводим двумерный массив по спирали
        System.out.println("\nСпиральный массив:");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                System.out.printf("%02d ", spiralArray[i][j]);
            }
            System.out.println();
        }
    }
}

