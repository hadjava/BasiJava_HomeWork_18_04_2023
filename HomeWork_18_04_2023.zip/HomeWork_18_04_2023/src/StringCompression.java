/*
 * Проект 2. Практика алгоритмов:
 * */
public class StringCompression {
    public static void main(String[] args) {
        String inputString = "AAABBBCCCDDEG";
        String compressedString = compressString( inputString );
        System.out.println( "Compressed String: " + compressedString );
    }

    private static String compressString(String input) {
        StringBuilder compressed = new StringBuilder();
        int count = 1;

        for (int i = 0; i < input.length() - 1; i++) {
            if (input.charAt( i ) == input.charAt( i + 1 )) {
                count++;
            } else {
                compressed.append( input.charAt( i ) );
                if (count > 1) {
                    compressed.append( count );
                }
                count = 1;
            }
        }

        // Добавляем последний символ и его количество (если больше 1)
        compressed.append( input.charAt( input.length() - 1 ) );
        if (count > 1) {
            compressed.append( count );
        }

        return compressed.toString();
    }
}
